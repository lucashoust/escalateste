const funcionarios=[
{nome:"BRUNO",sexo:"H",folgaFixa:"TER",ferias:[{inicio:"2026-02-02",fim:"2026-02-19"}]},
{nome:"ANA",sexo:"M",folgaFixa:"QUI",ferias:[]}
];